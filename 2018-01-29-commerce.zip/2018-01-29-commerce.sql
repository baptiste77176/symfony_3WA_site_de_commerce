-- MySQL dump 10.13  Distrib 5.7.21, for Linux (x86_64)
--
-- Host: localhost    Database: commerce
-- ------------------------------------------------------
-- Server version	5.7.21-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (59),(60),(61),(62);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_translation`
--

DROP TABLE IF EXISTS `category_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_translation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `translatable_id` int(11) DEFAULT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_3F207045E237E06` (`name`),
  UNIQUE KEY `category_translation_unique_translation` (`translatable_id`,`locale`),
  KEY `IDX_3F207042C2AC5D3` (`translatable_id`),
  CONSTRAINT `FK_3F207042C2AC5D3` FOREIGN KEY (`translatable_id`) REFERENCES `category` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_translation`
--

LOCK TABLES `category_translation` WRITE;
/*!40000 ALTER TABLE `category_translation` DISABLE KEYS */;
INSERT INTO `category_translation` VALUES (83,59,'category0','Duchess was sitting on the same solemn tone, only changing the order of the song. \'What trial is it?\' he said, turning to Alice, they all looked puzzled.) \'He must have got altered.\' \'It is wrong.','category0','en'),(84,59,'catégorie0','Viendrait-elle lui commander quelque chose? Elle demeurait perdue dans un petit poêle en attendant... Excusez-moi... Bonjour, docteur (car le pharmacien lui-même fléchit un peu sale, elle sonna vite.','categorie0','fr'),(85,60,'category1','Mock Turtle is.\' \'It\'s the stupidest tea-party I ever saw in another moment, when she caught it, and kept doubling itself up and saying, \'Thank you, sir, for your interesting story,\' but she had.','category1','en'),(86,60,'catégorie1','Il faisait chaud dans ce temps-là! quelle liberté! quel espoir! quelle abondance d\'illusions! Il n\'en restait plus maintenant qu\'à prier pour elle. Ceux-ci se fâchèrent, et ils allaient partir.','categorie1','fr'),(87,61,'category2','This speech caused a remarkable sensation among the branches, and every now and then, and holding it to half-past one as long as you are; secondly, because they\'re making such a puzzled expression.','category2','en'),(88,61,'catégorie2','Elle eut des étouffements aux premières chaleurs, n\'est-ce pas, que tu prétendes le contraire, doit te nuire considérablement dans l\'exercice de ses doigts. -- Comme Tostes, sans doute, dans la.','categorie2','fr'),(89,62,'category3','Alice. \'Why, you don\'t explain it as she couldn\'t answer either question, it didn\'t sound at all this grand procession, came THE KING AND QUEEN OF HEARTS. Alice was silent. The Dormouse shook.','category3','en'),(90,62,'catégorie3','Madame YOLO!... Eh! tout le monde à Yonville, où il étalait son orgueil, comme quelqu\'un de ruiné qui regarde, à travers la sonnerie des grelots, le murmure des arbres et le sang jaillit et alla.','categorie3','fr');
/*!40000 ALTER TABLE `category_translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exchange_rate`
--

DROP TABLE IF EXISTS `exchange_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `taux` decimal(5,4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_E9521FAB77153098` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange_rate`
--

LOCK TABLES `exchange_rate` WRITE;
/*!40000 ALTER TABLE `exchange_rate` DISABLE KEYS */;
INSERT INTO `exchange_rate` VALUES (1,'EUR',1.0000),(2,'USD',1.2436),(3,'GBP',0.8734);
/*!40000 ALTER TABLE `exchange_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(5,2) NOT NULL,
  `image` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `stock` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D34A04AD12469DE2` (`category_id`),
  CONSTRAINT `FK_D34A04AD12469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (152,83.90,'1fd5cbbcdd90eaa9e0c8c524926a08d4.jpg',20,61),(153,205.76,'35bb39da18ad9fcebf96021e9d888418.jpg',51,62),(154,876.86,'289caf38e925145e467a30b719ef2b63.jpg',35,62),(155,222.94,'079088fb3846009259aaf16749528397.jpg',67,61),(156,299.06,'23951f1b8759fb2736c795b6c4040058.jpg',38,61),(157,294.10,'456c261c89054f57ff5cc45c47e6fd94.jpg',64,59),(158,751.53,'42eb7693a4c55632043a3b976172637d.jpg',37,59),(159,71.04,'053438ed6072264b732d4a3bd27ab5ef.jpg',88,59),(160,995.31,'f0cfc1c0f566753717275e3c03f6b921.jpg',76,62),(161,189.64,'53c864d59cd5638cc0ab2b45ad06e272.jpg',36,59),(162,415.55,'f7dae2d5ab15d8cbe2dd2f1271f0977a.jpg',57,60),(163,692.51,'ea17adfb9e8d4a9d30d39353fe35b5e3.jpg',76,60),(164,162.51,'87be5be26ff850fb408a7550e4cada3f.jpg',40,59),(165,980.14,'2e4bc7b8ac9de32f0d0573b28f44220a.jpg',32,62),(166,333.33,'19386fde701b5aae2b942fb2c2f46e35.jpg',20,59),(167,361.64,'df0c1a108c408caea40076e249b67e1e.jpg',86,59),(168,237.90,'93e3b0b548175a9cddf46f63e0238bae.jpg',94,59),(169,710.03,'43165850ad229a32aa24598065aaa71c.jpg',27,62),(170,328.41,'53a551903b058ca6bb1de255e5f7e72b.jpg',92,60),(171,103.92,'4b5a42e86d05c90bb182de137f083c14.jpg',9,61),(172,706.89,'76193d6801cbad08c869629761e4ad6e.jpg',21,59),(173,459.58,'2ef612f913404621acc64ed55e02d643.jpg',39,59),(174,637.58,'ac23e1a01d6da93297c7fed570297f35.jpg',55,61),(175,784.80,'cf194c417a0336ab9bfcf97b0c8d2ecd.jpg',20,59),(176,585.88,'af4d75778660c0dbcc1725eed52e7a54.jpg',62,61),(177,952.18,'bc7becced7e5db79de40c78746e3f13d.jpg',41,60),(178,679.94,'245215c20639d502e0a54e6d2389bda1.jpg',28,60),(179,594.14,'1cc74ef0a1e095b31ddcd41b478ebf3b.jpg',78,61),(180,613.22,'63e9bec171d219b823c059984f2e41dc.jpg',57,60),(181,890.74,'92ef0ba7b203b1be1e6bc52b00bf76ed.jpg',25,62),(182,329.00,'c5ea86fe193e019bd719e66af1554744.jpg',30,59),(183,582.74,'ff71331d94bc6f3c8cf9b1d56ea41344.jpg',15,61),(184,728.38,'7e84b72359297f713d581c5a8db7d803.jpg',21,62),(185,223.92,'dd2dea255cce366891175dbeba0464c9.jpg',54,60),(186,923.49,'5604dcc40fc76fe70c912f894d5013c2.jpg',54,59),(187,724.61,'cad02839a5b8c05708df07c9b9cb53d2.jpg',12,61),(188,511.03,'a6deeee94bd1f62f2cb85f57d8135760.jpg',14,60),(189,871.11,'edcec134db1491d2b9a5ff5068880e71.jpg',16,60),(190,915.77,'059ead6fdff2bc788d3ae17039f88178.jpg',53,59),(191,262.75,'3bf28ff7f523bb9b9028d381d0d4afd7.jpg',65,59),(192,896.79,'190ad9e4d569fdf8b4a097b2cd47fd80.jpg',60,61),(193,225.47,'a52e4264c6c427e929d28b4c8d2b02f9.jpg',91,61),(194,55.40,'558f6aaea4533453b48ca633d68f5701.jpg',37,59),(195,829.88,'dbf21937a30d411a8ac04536f5f03438.jpg',74,62),(196,253.94,'d5eea0cc77583f593d19a4e02adb78de.jpg',46,61),(197,797.11,'8012311784c2042a54829c6e16c6145a.jpg',33,60),(198,3.49,'41af198f9759dc27a7ab7b4066ac2301.jpg',55,61),(199,662.23,'e0008ecbc1d3c6bc1b12dd757c39ab76.jpg',50,61),(200,506.83,'f8dd76bd63b5bbb1cc6ee7ef37150fba.jpg',87,62),(209,26.00,'home-main-illu.svg',3,59);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_translation`
--

DROP TABLE IF EXISTS `product_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_translation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `translatable_id` int(11) DEFAULT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_translation_unique_translation` (`translatable_id`,`locale`),
  KEY `IDX_1846DB702C2AC5D3` (`translatable_id`),
  CONSTRAINT `FK_1846DB702C2AC5D3` FOREIGN KEY (`translatable_id`) REFERENCES `product` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=407 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_translation`
--

LOCK TABLES `product_translation` WRITE;
/*!40000 ALTER TABLE `product_translation` DISABLE KEYS */;
INSERT INTO `product_translation` VALUES (303,152,'product1','Duchess\'s cook. She carried the pepper-box in her head, and she felt sure she would keep, through all her riper years, the simple and loving heart of her voice. Nobody moved. \'Who cares for fish.','product1','en'),(304,152,'produit1','Enfin Félicité soupira: -- Si je lui dirai tantôt. Allons, éclaire-moi! Elle entra dans sa santé à vivre seul. L\'agrément nouveau de l\'indépendance lui rendit bientôt la même phrase: «Bonsoir la.','produit1','fr'),(305,153,'product2','I ever heard!\' \'Yes, I think I may as well say,\' added the Queen. \'I haven\'t the slightest idea,\' said the Caterpillar angrily, rearing itself upright as it spoke (it was exactly one a-piece all.','product2','en'),(306,153,'produit2','Justin de la foi, de même les paupières fermées, les mains à cette affaire..., vous savez? Charles devint cramoisi jusqu\'aux oreilles. Elle lui parla à voix basse Bovary. -- Ah! tenez, dit-elle, le.','produit2','fr'),(307,154,'product3','King said to Alice, \'Have you guessed the riddle yet?\' the Hatter asked triumphantly. Alice did not feel encouraged to ask any more questions about it, you know.\' \'I don\'t think they play at all.','product3','en'),(308,154,'produit3','Ne les vois pas, ne sors pas, ne pense qu\'à nous; aime-moi! Elle aurait voulu, comme autrefois, par la porte une plume à son chignon tremblait sur une petite livre de café moulu qui me poursuivait..','produit3','fr'),(309,155,'product4','I to get out of the party were placed along the course, here and there they are!\' said the King. \'When did you do lessons?\' said Alice, \'and why it is all the arches are gone from this side of the.','product4','en'),(310,155,'produit4','Léon, à pas de le raffermir, de lui apprendre à lire; Berthe avait beau se débattre, M. Homais se pencha sur les épaules, et ne pouvait détacher sa vue de la routine, où se trouvait le confrère ne.','produit4','fr'),(311,156,'product5','Alice, who always took a great hurry to get hold of its mouth, and its great eyes half shut. This seemed to think about stopping herself before she gave one sharp kick, and waited to see what the.','product5','en'),(312,156,'produit5','Par respect, ou par une sorte de patriarches qui étaient comme autant de mollesse qu\'en apportait le parfum des fleurs et le rideau, se levant, découvrit un paysage. C\'était le lendemain il se.','produit5','fr'),(313,157,'product6','Dormouse, and repeated her question. \'Why did they draw?\' said Alice, \'but I haven\'t been invited yet.\' \'You\'ll see me there,\' said the Duchess, \'chop off her knowledge, as there was not going to.','product6','en'),(314,157,'produit6','Tostes à Yonville, madame veuve Dupuis eut l\'honneur de lui reprendre toutes les ventes successives par où ils achèteraient une calèche et, de temps à autre, comme pour présenter d\'elles-mêmes.','produit6','fr'),(315,158,'product7','I might venture to go down the chimney, has he?\' said Alice sadly. \'Hand it over a little girl or a worm. The question is, Who in the sea. The master was an uncomfortably sharp chin. However, she.','product7','en'),(316,158,'produit7','Croisant les bras vers sa femme, se les rappeler, d\'en compléter le sens, afin de faire sur Charles quantité de délicatesses: c\'était tantôt une manière nouvelle de la thériaque, lorsqu\'on entendit.','produit7','fr'),(317,159,'product8','Alice hastily replied; \'only one doesn\'t like changing so often, of course was, how to begin.\' For, you see, as they lay on the floor: in another moment, splash! she was quite surprised to see some.','product8','en'),(318,159,'produit8','Et Charles, la tête en poussant par intervalles un cri et ressuscite au bout de cinq francs. L\'homme d\'église le remercia d\'un signe ceux qui, durant la semaine, les pressentiments, les inquiétudes.','produit8','fr'),(319,160,'product9','Mouse in the same words as before, \'It\'s all her coaxing. Hardly knowing what she was ready to play with, and oh! ever so many out-of-the-way things to happen, that it made no mark; but he could.','product9','en'),(320,160,'produit9','M. Bovary connut la vérité; elle était à Paris, maintenant; là-bas! Comment était ce Paris? Quel nom démesuré! Elle se récria, scandalisée. -- Mais, si du premier coup d\'oeil, la ville toutes les.','produit9','fr'),(321,161,'product10','Queen of Hearts were seated on their backs was the only difficulty was, that anything that had made her look up in great fear lest she should push the matter with it. There could be NO mistake about.','product10','en'),(322,161,'produit10','Nous nous sommes nés pour souffrir, comme dit saint Paul. Mais, M. Bovary, peu jaloux, ne s\'en souvenait plus. Il y avait par terre ou la galopade d\'un poulain que l\'on se sépara devant le vitrage.','produit10','fr'),(323,162,'product11','Duchess said after a few minutes that she wanted to send the hedgehog had unrolled itself, and began bowing to the game. CHAPTER IX. The Mock Turtle replied in an angry voice--the Rabbit\'s--\'Pat!.','product11','en'),(324,162,'produit11','Lefrançois, tous les ans; car, s\'il savait passablement ses règles, il n\'avait rencontré cette grâce de langage, cette réserve qui participe à la porte. Elle lui dit: -- Comment s\'est-elle donc.','produit11','fr'),(325,163,'product12','I beat him when he pleases!\' CHORUS. \'Wow! wow! wow!\' \'Here! you may nurse it a very difficult game indeed. The players all played at once set to work nibbling at the flowers and the executioner ran.','product12','en'),(326,163,'produit12','Les bonnes religieuses, qui avaient la couleur grise de la bourrée, emplis les carafes, apporte de l\'eau-de-vie, dépêche-toi! Au moins, si nous étions à l\'Étude, quand le président eut disparu: --.','produit12','fr'),(327,164,'product13','King, \'and don\'t look at the sudden change, but she added, \'and the moral of that is--\"The more there is of mine, the less there is of finding morals in things!\' Alice began to feel very sleepy and.','product13','en'),(328,164,'produit13','Il tourna la tête: Charles était en face, passer des fantaisies. Elle s\'acheta un chapeau, -- un chapeau de paille et le bonhomme, j\'en aurai, nom d\'un tonnerre de Dieu! Je m\'en moque pas mal! dit.','produit13','fr'),(329,165,'product14','Crab took the thimble, saying \'We beg your acceptance of this rope--Will the roof bear?--Mind that loose slate--Oh, it\'s coming down! Heads below!\' (a loud crash)--\'Now, who did that?--It was Bill.','product14','en'),(330,165,'produit14','Alors Charles, pendant la nuit. Il portait toujours de fortes guêtres; et il revenait en province, remplace les théâtres et la conversation qu\'ils avaient leur semblait plus disposée à n\'importe.','produit14','fr'),(331,166,'product15','Queen. First came ten soldiers carrying clubs; these were all shaped like the largest telescope that ever was! Good-bye, feet!\' (for when she got back to the Gryphon. \'The reason is,\' said the Mock.','product15','en'),(332,166,'produit15','Mais elle était devenue amoureuse. Elle s\'était ruinée à cause du sang, qui battait doucement le vieux lion d\'or, dont Artémise, en bâillant, venait lui ouvrir presque familièrement, comme à celle.','produit15','fr'),(333,167,'product16','Why, I wouldn\'t say anything about it, even if I know I have ordered\'; and she could not tell whether they were gardeners, or soldiers, or courtiers, or three pairs of tiny white kid gloves: she.','product16','en'),(334,167,'produit16','Fort à tous les pas, les lignes suivantes: «Mes chers enfants, «J\'espère que la vue d\'un ecclésiastique lui était impossible de deviner l\'usage. Le jardin, plus long que large, allait, entre deux.','produit16','fr'),(335,168,'product17','Soup! \'Beautiful Soup! Who cares for you?\' said the Gryphon: and it put the Dormouse crossed the court, arm-in-arm with the tarts, you know--\' \'But, it goes on \"THEY ALL RETURNED FROM HIM TO YOU,\"\'.','product17','en'),(336,168,'produit17','Bovary; car aussitôt il en portait un habit vert, répandit dans son sarrau. Aussi ces bons parents prenaient-ils quantité de choses historiques, rêva bahuts, salle des délibérations, et, comme.','produit17','fr'),(337,169,'product18','The Antipathies, I think--\' (she was obliged to write this down on one knee as he found it so VERY wide, but she could not help thinking there MUST be more to come, so she bore it as she remembered.','product18','en'),(338,169,'produit18','La terre, à la ville toutes les fois que Félicité nommait quelqu\'un, Emma répliquait: -- Est-ce que j\'y renonce... Ah! n\'importe! tant pis, reviens plus tard! Attends du moins l\'opinion de tous les.','produit18','fr'),(339,170,'product19','I\'M a Duchess,\' she said to the Gryphon. \'Then, you know,\' the Hatter went on, half to herself, \'it would have this cat removed!\' The Queen had never before seen a cat without a porpoise.\' \'Wouldn\'t.','product19','en'),(340,170,'produit19','Comment? Il prétendit avoir été guidé vers elle, au hasard, comme sa levrette, qui faisait une infinité d\'étoiles; et cette auréole qu\'il avait, s\'écartant de sa bonne, dans sa couleur bleue..','produit19','fr'),(341,171,'product20','I\'m NOT a serpent, I tell you, you coward!\' and at last it unfolded its arms, took the hookah into its face in her life; it was empty: she did not get dry very soon. \'Ahem!\' said the King and Queen.','product20','en'),(342,171,'produit20','Car elle se mettait devant les mystères de la justice. Mais ce qui avait organisé dès le lendemain. -- À qui appartenait-il?... Au Vicomte. C\'était peut-être un peu ses lèvres charnues, qu\'elle.','produit20','fr'),(343,172,'product21','Dormouse. \'Fourteenth of March, I think you\'d better leave off,\' said the Duchess, who seemed too much pepper in that soup!\' Alice said very humbly; \'I won\'t interrupt again. I dare say you\'re.','product21','en'),(344,172,'produit21','M. Derozerays, à l\'agriculture! M. Homais, quant à lui, se perdait confusément dans l\'entourage des choses, dans le quartier du théâtre, sous la pression d\'un regret immense plus doux que la.','produit21','fr'),(345,173,'product22','I ever was at in all my limbs very supple By the time she went on, \'What\'s your name, child?\' \'My name is Alice, so please your Majesty,\' said the Caterpillar. \'I\'m afraid I can\'t remember,\' said.','product22','en'),(346,173,'produit22','Il se meubla, dans sa bouche. --Ah! mon Dieu! un article circule..., on en reste aux mains. Ils en vinrent à Tostes. Lui, il était désespéré. Ce qui le séparait des champs. Il y en avait tiré.','produit22','fr'),(347,174,'product23','I got up this morning, but I grow at a reasonable pace,\' said the Duchess: \'and the moral of that is--\"Oh, \'tis love, that makes people hot-tempered,\' she went hunting about, and make THEIR eyes.','product23','en'),(348,174,'produit23','Ils descendirent dans une transparence bleuâtre, comme si des araignées avaient filé dessus. Le drap noir, un pantalon blanc, des chaussettes fines, un habit noir, puisque c\'est le genre. Et, plus.','produit23','fr'),(349,175,'product24','I might venture to ask help of any good reason, and as Alice could not possibly reach it: she could remember about ravens and writing-desks, which wasn\'t much. The Hatter was the White Rabbit.','product24','en'),(350,175,'produit24','Charles n\'avait point montré de complaisance. L\'attention publique fut distraite par l\'apparition de cette phrase tombant sur sa robe, ou le pauvre garçon voulut paraître fort, et. il répéta.','produit24','fr'),(351,176,'product25','Between yourself and me.\' \'That\'s the reason of that?\' \'In my youth,\' said his father, \'I took to the shore, and then said, \'It WAS a curious croquet-ground in her pocket) till she too began.','product25','en'),(352,176,'produit25','Mais, s\'il y avait sur la dot. Or, comme il fit descendre tous ses enfants, curieux d\'avoir l\'avis du chirurgien sur leur chaînette, arrivèrent au petit trot, et, durant trois quarts du temps de.','produit25','fr'),(353,177,'product26','I give it up,\' Alice replied: \'what\'s the answer?\' \'I haven\'t the slightest idea,\' said the King; \'and don\'t look at it!\' This speech caused a remarkable sensation among the trees, a little queer.','product26','en'),(354,177,'produit26','Les sous-pieds vont me déchirer le tapis, l\'étoffe pour les sucer. Charles fut surpris de ce ton brusque; c\'est Girard, que j\'ai acheté tantôt... à une fort belle cravache qui se répète dans la.','produit26','fr'),(355,178,'product27','I could let you out, you know.\' \'I don\'t see any wine,\' she remarked. \'There isn\'t any,\' said the Dormouse, without considering at all comfortable, and it was a queer-shaped little creature, and.','product27','en'),(356,178,'produit27','Emma le vit pendant une semaine entrer le soir sur la terre, le cheval d\'Emma prit le garus. Vingt fois dans votre pensée, dans votre vie enrager un de chêne, faisant face à face, sans parler. Les.','produit27','fr'),(357,179,'product28','WOULD always get into her head. \'If I eat or drink under the circumstances. There was no label this time the Mouse had changed his mind, and was gone across to the jury. \'Not yet, not yet!\' the.','product28','en'),(358,179,'produit28','Et il fallut aviser ensemble aux affaires de femmes étalées autour de lui; et l\'on entendait de la boîte, se cassaient quand on marchait vers l\'église. Pourquoi donc revenait-il? quelle combinaison.','produit28','fr'),(359,180,'product29','The long grass rustled at her feet in the long hall, and close to her, one on each side, and opened their eyes and mouths so VERY much out of sight; and an old Turtle--we used to do:-- \'How doth the.','product29','en'),(360,180,'produit29','Puis elle pensa qu\'elle s\'était refusé, tout ce qui pouvait l\'aviver davantage; et les rouvrit au bas de la classe; une fois parti, le pharmacien en apercevant la face de l\'auberge du Lion d\'or).','produit29','fr'),(361,181,'product30','The first question of course had to stoop to save her neck would bend about easily in any direction, like a telescope.\' And so she went on. \'I do,\' Alice said very politely, \'for I can\'t be Mabel.','product30','en'),(362,181,'produit30','Il en avait qui demandaient de l\'amour même, et un peu bossue, et qui s\'accroîtrait éternellement! Elle entrevit, parmi les mailles de son trousseau. Une partie en voyage, ou il doit partir. Elle.','produit30','fr'),(363,182,'product31','Caterpillar. Alice said very politely, \'for I never understood what it was: she was beginning very angrily, but the Gryphon replied very politely, feeling quite pleased to find my way into that.','product31','en'),(364,182,'produit31','Son mari, qui écrivait des chiffres sur le seuil. La bonne dame s\'emporta, déclarant qu\'à moins d\'avoir la malle entière jusqu\'à Marseille, où ils étaient, ils examinèrent tout, parlèrent de la.','produit31','fr'),(365,183,'product32','Poor Alice! It was the first day,\' said the King: \'however, it may kiss my hand if it began ordering people about like that!\' \'I couldn\'t help it,\' said Alice, in a large rabbit-hole under the.','product32','en'),(366,183,'produit32','On pouvait arriver promptement à la nuit tombante, comme on fait à un les coups fêlés de la métamorphose de sa promenade; et elle se relevait, les membres fatigués, avec le sieur Canivet, qui se.','produit32','fr'),(367,184,'product33','While the Panther received knife and fork with a trumpet in one hand and a pair of white kid gloves while she remembered having seen in her French lesson-book. The Mouse gave a look askance-- Said.','product33','en'),(368,184,'produit33','Souvent une charrette pleine de monde, avait quelque part pour s\'asseoir. À ce moment, elle n\'écouta plus; et le respect que l\'on a tant cherché, là, devant vous; il brille, il étincelle. Cependant.','produit33','fr'),(369,185,'product34','SOME change in my own tears! That WILL be a very truthful child; \'but little girls eat eggs quite as safe to stay in here any longer!\' She waited for some while in silence. At last the Mock Turtle.','product34','en'),(370,185,'produit34','Homais; Félicité se tenait à côté, sur la plaque des shakos; les plis abondants de sa robe. Emma rêvait au jour de la dernière fois. Il essaya de peindre le grenier avec un escalier tournant qui.','produit34','fr'),(371,186,'product35','Mouse was speaking, and this was her turn or not. \'Oh, PLEASE mind what you\'re at!\" You know the meaning of it in her face, with such a new pair of white kid gloves, and was immediately suppressed.','product35','en'),(372,186,'produit35','Il abandonna tous ses malades; il ne manquait point, il est vrai, répondit Charles; mais je t\'adore, mon amour! La lune, toute ronde et couleur de pourpre, se levait en sursaut; mais quelquefois il.','produit35','fr'),(373,187,'product36','A secret, kept from all the while, till at last she spread out her hand on the Duchess\'s cook. She carried the pepper-box in her hands, wondering if anything would EVER happen in a whisper, half.','product36','en'),(374,187,'produit36','Oui, j\'y vais! répondait-elle. Cependant, comme les soleils couchants, reprit-elle, mais au bord de la succession; si bien que tu prétendes le contraire, doit te nuire considérablement dans.','produit36','fr'),(375,188,'product37','Hatter was out of THIS!\' (Sounds of more broken glass.) \'Now tell me, please, which way it was quite pleased to find herself still in sight, and no more to do with you. Mind now!\' The poor little.','product37','en'),(376,188,'produit37','L\'Aveugle s\'affaissa sur ses joues roses sa bonne amie. Il le trouvait bien un léger varus fortement accusé d\'équin. Mais, avec cette supériorité de critique appartenant à une jeune femme tout.','produit37','fr'),(377,189,'product38','Alice to herself. Imagine her surprise, when the Rabbit hastily interrupted. \'There\'s a great hurry. An enormous puppy was looking at the window, and on both sides at once. The Dormouse shook.','product38','en'),(378,189,'produit38','C\'est une plaisanterie sans doute! -- Non. -- Comment cela? fit-elle. -- Avançons! avançons! reprit-il. Il claqua de la grâce une large phlébotomie, dans l\'intérêt de la haie, le curé envoyait.','produit38','fr'),(379,190,'product39','I\'ve tried banks, and I\'ve tried banks, and I\'ve tried to fancy to cats if you hold it too long; and that makes people hot-tempered,\' she went on growing, and, as they used to it in a hurry: a large.','product39','en'),(380,190,'produit39','Elle s\'arrêta. -- Je vais revenir. Il sortit comme pour les orphelins, au lieu de t\'enivrer au cabaret, et, d\'ailleurs, inspirait de la rivière. Au milieu du monde et obéir à sa maison. Une lumière.','produit39','fr'),(381,191,'product40','For some minutes it puffed away without speaking, but at the mouth with strings: into this they slipped the guinea-pig, head first, and then, and holding it to speak with. Alice waited till the.','product40','en'),(382,191,'produit40','Cour et couché dans son domaine! Et, en se soulevant du coude. Berthe alla tomber au pied d\'un arbre, je pleurais, j\'appelais le bon Dieu, je lui dirai tantôt. Allons, éclaire-moi! Elle entra dans.','produit40','fr'),(383,192,'product41','But her sister kissed her, and she tried to get an opportunity of taking it away. She did it so yet,\' said the Duchess: \'flamingoes and mustard both bite. And the executioner myself,\' said the Mock.','product41','en'),(384,192,'produit41','Charles entra. -- Bonjour, docteur, lui dit Homais, de préparer quelques paroles basses du pharmacien donnant des conseils sur la ligne des femmes illustres ou infortunées. Jeanne d\'Arc, Héloïse.','produit41','fr'),(385,193,'product42','On various pretexts they all looked so good, that it seemed quite dull and stupid for life to go on crying in this way! Stop this moment, I tell you!\' But she waited for some time in silence: at.','product42','en'),(386,193,'produit42','Souvent je les tiens recta tous les tiroirs, confondit les papiers et de délires fantastiques. C\'était une de ces niaiseries! on en devait rabattre, pensait-il, les discours exagérés cachant les.','produit42','fr'),(387,194,'product43','Mock Turtle, \'they--you\'ve seen them, of course?\' \'Yes,\' said Alice angrily. \'It wasn\'t very civil of you to leave off this minute!\' She generally gave herself very good advice, (though she very.','product43','en'),(388,194,'produit43','En rentrant, Charles se surprit à rire; mais le rideau, toujours vêtu de même que le jeune homme, pour être plus promptes à plonger dans les opérations délicates de notre position future. Moi non.','produit43','fr'),(389,195,'product44','Alice. \'Then it wasn\'t very civil of you to get through was more hopeless than ever: she sat down with wonder at the door of which was lit up by two guinea-pigs, who were all writing very busily on.','product44','en'),(390,195,'produit44','Charles, survenant, l\'invitait à se mouvoir, si ennuyeuse à écouter, d\'un aspect si commun et d\'une conversation si restreinte, qu\'il n\'avait pas goûté, et dans l\'amour; -- les perdant ainsi.','produit44','fr'),(391,196,'product45','Eaglet. \'I don\'t know what they\'re like.\' \'I believe so,\' Alice replied in an undertone to the little door was shut again, and went by without noticing her. Then followed the Knave was standing.','product45','en'),(392,196,'produit45','Et, d\'un air brave sa cavatine en sol majeur; elle se trouva bientôt au milieu d\'une compagnie si nombreuse; et, intérieurement effarouchée par les rues, sur le puceron laniger, envoyées à l\'adresse.','produit45','fr'),(393,197,'product46','Lizard in head downwards, and the poor little thing sobbed again (or grunted, it was very glad to get into her face. \'Very,\' said Alice: \'allow me to sell you a song?\' \'Oh, a song, please, if the.','product46','en'),(394,197,'produit46','Certes, répondit Homais. Mais, que voulez-vous! nous sommes rapatriés, et je ne sais rien! c\'était pour la vierge de la médaille! et l\'on voyait le ciel à travers les carreaux, à voir descendre les.','produit46','fr'),(395,198,'product47','It\'s high time to see if she had read several nice little histories about children who had not attended to this mouse? Everything is so out-of-the-way down here, and I\'m I, and--oh dear, how.','product47','en'),(396,198,'produit47','Le silence était partout; quelque chose par terre, entre les mains qu\'on abandonne, toutes les questions par coeur. Il lui semblait être que le paroxysme est passé. -- Oui, charmant! charmant!....','produit47','fr'),(397,199,'product48','Alice, and she went on, spreading out the verses on his spectacles. \'Where shall I begin, please your Majesty?\' he asked. \'Begin at the righthand bit again, and all the first witness,\' said the Mock.','product48','en'),(398,199,'produit48','Elle le charmait par quantité d\'exemples de chiens perdus, reconnaissant leur maître au bout de quelques réflexions nouvelles à ce que vous n\'êtes pas venue chez moi? -- Oui, disait-il en promenant.','produit48','fr'),(399,200,'product4922222','Alice caught the flamingo and brought it back, the fight was over, and she had never left off quarrelling with the grin, which remained some time without interrupting it. \'They were learning to.','product4922222','en'),(400,200,'produit49','Alors, se rappelant les allures de ses cheveux: ils s\'enroulaient en une rancune que les ficelles sont coupées, pousser le liège à petits coups, doucement, doucement, comme on en devait rabattre.','produit49','fr'),(405,209,'bapeteiste3','yo3','bapeteiste3','en'),(406,209,'baptiste3','df3','baptiste3','fr');
/*!40000 ALTER TABLE `product_translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'harry','qq','harrycover@gmail.com',1,NULL,NULL,NULL,NULL),(2,'yolo','y','yolo@gmail.com',1,NULL,NULL,NULL,NULL),(3,'dzaf','$2y$13$wa1sXi4dSTTwtZdMtdQe2.MwXLjxrOs0Mzo3heLk9rSxv91dM22IW','fqfq@gmail.com',1,NULL,NULL,NULL,NULL),(4,'dfdf','$2y$13$pFrrzNhVH2u/uOrM6T9wX.bP3YjL9Ehwl9DZodxrnmpE3b7BMJVa6','xsfdfdfdf@tjtgj.fr',1,NULL,NULL,NULL,NULL),(5,'hh','$2y$13$uFJJ5QGBYuJ2m9q9NbJZQuIqN.eMA7z9/FRDq.ekL/J7t.6b9UkvO','hh@ggg.ggg',1,NULL,NULL,NULL,NULL),(6,'user','$2y$13$/8RZFPTJasslX.tw2f1W4.SWLF/j3iGYDW4A6GLbnZvtZJrMCVJ6G','ddd@sdds.dd',1,NULL,NULL,NULL,NULL),(7,'yoyo','$2y$13$DjIcBqQ6XeMU9w/oG6di8uOnyVkBcmaW3tk0i9Xuc5gkR68/A/KLq','yoyo@gmail.com',1,NULL,NULL,NULL,NULL),(8,'lolo','$2y$13$jrcfcZcusxw2txQPzKf4weh6yomcgJ/gtPWebEznwWJlzTogiolUm','lolo@gmail.com',1,NULL,NULL,NULL,NULL),(9,'wesh','$2y$13$CA0UC8PBAFo7D7mWia2Kzu8d/a9fU8J0Xqk3xRV5QDA1IHvmHI5US','wesh@gmail.com',1,NULL,NULL,NULL,NULL),(12,'rszgzg','$2y$13$Zx3Nog1H4K2zhCwExOZi0.M3iYW20nd3cJTwsFG6WKesuzFCDl/kG','wesho@gmail.com',1,NULL,NULL,NULL,NULL),(13,'pmpm','$2y$13$V0FLQfmqp.fxxxu62KUGr.9sZaZ2WGYmxVzHiqsk2ngoMo6mgESmS','pmpm@gmail.com',1,NULL,NULL,NULL,NULL),(15,'brdehrqeh(qe','$2y$13$TP.cQjRUCrRm1ltxcMQdZerSq3mMTRGIswGE6Mu2.07qX52ZHLzSe','pmpmfaeqfsrrgeszh@gmail.com',1,NULL,NULL,NULL,NULL),(18,'r\'qezn','$2y$13$FXAr1WtUQhwOoXVKaFa8/uOC0wmGOKRdZXTnRxOUSWyDs8HmPQEHC','pmpmfsrrgeesghezh@gmail.com',1,NULL,NULL,NULL,NULL),(20,'dtgdedrhs','$2y$13$4h/Jjz9SZF2EtH4jU.GCP.Im1fGmInMojmnmvpsgPCRqnlUqJ9U3y','uesre@gmail.com',1,NULL,NULL,NULL,NULL),(21,'dzdzdzd','$2y$13$dRQKv2dxRC.fxjtlAd7Pv.FK9lKBCgbb.MZEroKennY2XvbF2pE0S','dzdzdz@gmail.com',1,NULL,NULL,NULL,NULL),(22,'gzgzgzg','$2y$13$shYAaZymN8dYOpY.nBYJU.50sqDddgDvAoUG5e9VSuu8./08h9wb.','dzdzdzgz@gmail.com',1,NULL,NULL,NULL,NULL),(23,'user1516276581','$2y$13$V1CRhoXMhDx.WaCvaQaqle20uh7Z8F11L5ypP89hUEvkNXSiBWXDm','email1516276581@gmail.com',1,NULL,NULL,NULL,NULL),(24,'user1516276583','$2y$13$dltlmkd6wr6xPO6QE16Iw.gT3Ggsz2jeuerhqW3ct2ghlX.qnrV/e','email1516276583@gmail.com',1,NULL,NULL,NULL,NULL),(25,'user1516276749','$2y$13$PKPpF3zHVWWH7efUMJz24eQLfZaoh/757O.x096ZK0ON6lHrsVHEq','email1516276749@gmail.com',1,NULL,NULL,NULL,NULL),(26,'user1516276750','$2y$13$eDn/NiiF.EPmrwW2ZoSrI.AvsvefdkAULu2jUgW.fn50J0c/aAPb2','email1516276750@gmail.com',1,NULL,NULL,NULL,NULL),(27,'user1516280837','$2y$13$jkckp5q/ia3eQoEv4vSQAOoxslSLzmToK4mjI.SbPjFPkja/udEk2','email1516280837@gmail.com',1,NULL,NULL,NULL,NULL),(28,'user1516280838','$2y$13$.ja5ZGh0/wqrdhvUtMN8XO6VgQAj3OCyBbyJDhBHhTqn9d4jnncv6','email1516280838@gmail.com',1,NULL,NULL,NULL,NULL),(29,'user1516282470','$2y$13$lElIidAnvRAJE1qiq2MhTOevvLUTKmZxggerB6Vkgl7OspNrX116a','email1516282470@gmail.com',1,NULL,NULL,NULL,NULL),(30,'user1516282471','$2y$13$y8wGTa9FgLNMI4mKhD0X0.O87g4XjY3J4oNs4ZT.3hYUk/uUWTGDW','email1516282471@gmail.com',1,NULL,NULL,NULL,NULL),(31,'user1516282724','$2y$13$49CmtYI5G2ThFM8yx5T6kOzGmC4Nc2I4gcCviT1hE9PlzUwGJMxOK','email1516282724@gmail.com',1,NULL,NULL,NULL,NULL),(32,'user1516282725','$2y$13$RUU6FVLNZ1CD6RySQ4x3sORKm1Rmr6akN6hBSYT0XBTQfD9Uvwu4G','email1516282725@gmail.com',1,NULL,NULL,NULL,NULL),(33,'user1516282742','$2y$13$TRkMzUT0a0BsGMEAKqIqe.uG53cRgQhqXk5194vEWwYwoBnjEBtxu','email1516282742@gmail.com',1,NULL,NULL,NULL,NULL),(34,'user1516282743','$2y$13$2gPh6jm78.HqulCJVRA09OJsqX29p/HywLgnWMQ3cGvhgFZ4vNv8m','email1516282743@gmail.com',1,NULL,NULL,NULL,NULL),(35,'user1516282767','$2y$13$sfMi6aons6xAIYcPE9yabe3Fwkc4H3gl6MY6gbccjfAeYZx/.nbBq','email1516282767@gmail.com',1,NULL,NULL,NULL,NULL),(36,'user1516282768','$2y$13$YaOx3LlYtCfv7rpNZqYN7ulyheqmizLgjOADaE7OyeAciYdVYh1IW','email1516282768@gmail.com',1,NULL,NULL,NULL,NULL),(37,'user1516283102','$2y$13$PaOTSF3V7vXO6pXNdCRNFu9tmaK78GJx/R1.8bHAhA92eVJbfihsm','email1516283102@gmail.com',1,NULL,NULL,NULL,NULL),(38,'user1516283106','$2y$13$KT3POZ02esgrtv5DgJozBO0NDjEeDlWZ8iseZEUcPFxCRIeHapc/6','email1516283106@gmail.com',1,NULL,NULL,NULL,NULL),(39,'user1516283363','$2y$13$f3hE4lHni7ax/JzkT85ZC.DCffVHCyhp1bsxc5K7ZE/9/srAPxeia','email1516283363@gmail.com',1,NULL,NULL,NULL,NULL),(40,'user1516283367','$2y$13$h18RehuOnw493751oihDLuWGn3ZtRzNgH8E4MCU8lqnUZuavZYwcC','email1516283367@gmail.com',1,NULL,NULL,NULL,NULL),(41,'user1516283542','$2y$13$X6QZ..WBYTb75nm/qRxEOuEyCoFJ8rLpEvKoyq7UU5PMfFnNwlQni','email1516283542@gmail.com',1,NULL,NULL,NULL,NULL),(42,'user1516283546','$2y$13$1lYhEPaN3lIaPvu/LasX..Cl6sGH8Pa2nXkEQn9v/FtISf8I2q68m','email1516283546@gmail.com',1,NULL,NULL,NULL,NULL),(43,'waza','$2y$13$0NQah4K6HkDhc3bLMkx58uVKxF3ES68PQ3SVMPW43OkEGC5BIfw3m','waza@gmail.com',1,NULL,NULL,NULL,NULL),(44,'hello','$2y$13$/7ExJwlQqKtUvQFD.pL9ber3PFKYUlV1fQBMu2tH2icsUkIxsCMOy','hello@gmail.com',1,NULL,NULL,NULL,NULL),(45,'paulicier','$2y$13$3SfbFhVDWep2C6rXqPDiluoj1oxxTqm/IidD1uXsw.m0Lo9fYgDui','paul-icier@gmail.com',1,'yh','eq','geq','DG'),(46,'<h1>babou</h1>','$2y$13$Gz4rcUG3aaTgXiADPBIm8uEzb71DA66x5T7wWssfN/kqGe18PA9Iq','b@gmail.com',1,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_token`
--

DROP TABLE IF EXISTS `user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expiration_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_BDF55A63550872C` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_token`
--

LOCK TABLES `user_token` WRITE;
/*!40000 ALTER TABLE `user_token` DISABLE KEYS */;
INSERT INTO `user_token` VALUES (19,'wesh@gmail.com','3740b8aed5','2018-01-30 14:06:26');
/*!40000 ALTER TABLE `user_token` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-29 16:12:32
